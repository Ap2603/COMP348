
package lib;

/**
 * @author Alessandro Dare
 * @version 1.0
 * Interface the make sure all classes with this interface can print their values
 */
public interface Printable {
	public void print();
	/**
	 * Gets a list of all printable objects and prints their values
	 * @param pritnList Printable list of printable objects 
	 */
	public static void print(Printable... pritnList) {
		System.out.println("Printing List:");
		for (Printable printable : pritnList) {
			printable.print();
		}
	}
}
