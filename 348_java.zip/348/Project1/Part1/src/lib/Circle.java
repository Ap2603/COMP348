package lib;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author Alessandro Dare
 * @version 1.0
 * Class that represents a circle, giving you it's area, perimeter and name
 */
public class Circle extends PrintableObject implements Shape {
	private double radius;
	private static final int NUMBEROFPARAMETERS=2;
	
	/**
	 * Default constructor
	 */
	public Circle() {

	}
	/**
	 * Constructor that takes in the radius of the circle
	 * @param radius double
	 */
	public Circle(double radius) {
		this.radius = radius;
	}
	/**
	 * Gets information of a circle from the text file and uses it to create a circle object with given parameters
	 * @param circleInfo String
	 * @return Circle the completed circle 
	 * @throws InvalidCircleParameterException thrown if the circle's values are invalid
	 */
	public static Circle parse(String circleInfo) throws InvalidCircleParameterException {
		List<String> infoList = new ArrayList<String>(Arrays.asList(circleInfo.split(",")));
		// checks if their are too many or not enough variables for a circle
		if(infoList.size()!=NUMBEROFPARAMETERS) {
			throw new InvalidCircleParameterException("The cricle has invalid number of parameters:"+infoList.size());
		}
		try {
		 // converts the text file parameters into doubles
		 double radius = Double.parseDouble(infoList.get(1));
		 Circle newCircle = new Circle(radius);
		 return newCircle;
		}
		// thrown if the parameter for the radius cannot be converted to doubles
		catch(java.lang.NumberFormatException e) {
			throw new InvalidCircleParameterException("The cricle has invalid parameters: radius: "+infoList.get(1)+" is not a number");
		}
		
	}
	public void setRadius(double radius) {
		this.radius = radius;
	}

	public double getRadius() {
		return this.radius;
	}
	/**
	 * get's the name of the circle in all caps
	 * @return String circle name
	 */
	public String getName() {
		return this.getClass().getName().toUpperCase();
	}
	/**
	 * Overrides the to string method to get it's name, and radius
	 */
	@Override 
	public String toString() {
		String name = this.getName();
		return name + "," + this.radius;
	}
	/**
	 * returns the preimeter of the rectangle
	 * @return double preimeter of the rectangle
	 */
	public double getPerimeter() {
		return 2 * this.radius * Math.PI;
	}
	/**
	 * returns the area of the rectangle
	 * @return double area of the rectangle
	 */
	public double getArea() {
		return this.radius * this.radius * Math.PI;
	}
}