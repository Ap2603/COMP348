
package lib;

import java.util.Comparator;

/**
 * @author Alessandro Dare
 * @version 1.0
 * Comparison class sorts shapes numerically by Area 
 */
public class SortByArea implements Comparator<Shape> {
	/**
	 * main comparison method
	 * @param shape1 Shape
	 * @param shape2 Shape
	 * @return int value of the comparison (shows which shape is greater then which)
	 */
	@Override
	public int compare(Shape shape1, Shape shape2) {
		
		//find the difference in the two doubles
		double difference = Math.rint(shape1.getArea() - shape2.getArea());
		//converts to an int so it can be compared by the list
		int differenceInt = (int) difference;
		return differenceInt;
	}
}
