
package lib;

/**
 * @author Alessandro Dare
 * @version 1.0
 * Shape interface sets that all shapes have to provide and area and perimeter
 */
public interface Shape {
	/**
	 * @return double perimeter of the object
	 */
	public double getPerimeter();
	
	/**
	 * @return double area of the object
	 */
	public double getArea();
}
