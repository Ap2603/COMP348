package lib;

/**
 * @author Alessandro Dare
 * @version 1.0
 * Throws an exception when a circle shape is given incorrect info in the text file
 */
public class InvalidCircleParameterException extends Exception  
{  
	/**
	 * Main constructor of the class
	 * @param message String error message
	 */
    public InvalidCircleParameterException (String message)  
    {  
         
        super(message);  
    }  
}