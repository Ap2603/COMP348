
 
package lib;

import java.util.Comparator;

/**
 * @author Alessandro Dare
 * @version 1.0
 * Comparison class sorts shapes alphabetical by name  
 */
public class SortByName implements Comparator<Shape> {
	private static final String RECTANGLE = "lib.Rectangle";
	private static final String CIRCLE = "lib.Circle";
	/**
	 * main comparison method
	 * @param shape1 Shape
	 * @param shape2 Shape
	 * @return int value of the comparison (shows which shape is greater then which)
	 */
	@Override
	public int compare(Shape shape1, Shape shape2) {
		//finds the class of both shapes (rectangle or circle) then casts the shapes to their class so it can compare their names 
		if (shape1.getClass().getName().equals(RECTANGLE) && shape2.getClass().getName().equals(RECTANGLE)) {
			return (((Rectangle) shape1).getName()).compareTo((((Rectangle) shape2).getName()));
		} else if (shape1.getClass().getName().equals(CIRCLE) && shape2.getClass().getName().equals(RECTANGLE)) {
			return (((Circle) shape1).getName()).compareTo((((Rectangle) shape2).getName()));
		} else if (shape1.getClass().getName().equals(RECTANGLE) && shape2.getClass().getName().equals(CIRCLE)) {
			return (((Rectangle) shape1).getName()).compareTo((((Circle) shape2).getName()));
		} else {
			return (((Circle) shape1).getName()).compareTo((((Circle) shape2).getName()));
		}

	}

}