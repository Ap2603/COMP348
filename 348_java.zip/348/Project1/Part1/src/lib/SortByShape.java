
package lib;

import java.util.Comparator;

/**
 * @author Alessandro Dare
 * @version 1.0
 * Comparison class combines two comparison classes and sorts shapes by both comparators
 */
public class SortByShape implements Comparator<Shape> {

	private Comparator<Shape> comparatorOne;
	private Comparator<Shape> comparatorTwo;
	/**
	 * Main constructor of the class takes both comparators it will use
	 * @param comparator1 Comparator<Shape>
	 * @param comparator2 Comparator<Shape>
	 */
	public SortByShape(Comparator<Shape> comparator1, Comparator<Shape> comparator2) {
		this.comparatorOne = comparator1;
		this.comparatorTwo = comparator2;
	}
	/**
	 * Main comparison method combines the comparisons of the other 2 classes
	 * @param shape1 Shape
	 * @param shape1 Shape
	 * @return int value of the comparison (shows which shape is greater then which)
	 */
	@Override
	public int compare(Shape shape1, Shape shape2) {
		// make a first comparison using comparator one
		int comparisonByOne = comparatorOne.compare(shape1, shape2);

		// check if it was 0 (items equal in that attribute)
		if (comparisonByOne == 0) {
			// if yes, return the result of the next comparison
			return comparatorTwo.compare(shape1, shape2);
		} else {
			// otherwise return the result of the first comparison
			return comparisonByOne;
		}
	}

}
