package lib;

/**
 * @author Alessandro Dare
 * @version 1.0
 * Class that represents an object that can print and return it's name
 */
public abstract class PrintableObject implements Printable, NamedObject {
	/**
	 * Overrides the to string method to give the object's name
	 * @return String the object's name
	 */
	@Override
	public String toString() {
		return this.getName();
	}
	/**
	 * prints the objects name
	 */
	public void print() {
		System.out.println(this.toString());
	}
}
