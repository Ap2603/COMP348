/**
 * 
 */
package lib;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author Alessandro Dare
 * @version 1.0
 * Class that represents a rectangle, giving you it's area, perimeter and name
 */
public class Rectangle extends PrintableObject implements Shape {
	private double height;
	private double width;
	private static final int NUMBEROFPARAMETERS = 3;

	/**
	 * Default constructor
	 */
	public Rectangle() {

	}
	/**
	 * Constructor that takes in height and width of the constructor
	 * @param height double
	 * @param width double
	 */
	public Rectangle(double height, double width) {
		this.height = height;
		this.width = width;
	}
	/**
	 * Overrides the to string method to get it's name, height, and width
	 */
	@Override
	public String toString() {
		String name = this.getName();
		return name + "," + this.height + "," + this.width;
	}
	/**
	 * Gets information of a rectangle from the text file and uses it to create a rectangle object with given parameters
	 * @param retangleInfo String
	 * @return Rectangle the completed rectangle 
	 * @throws InvalidCircleParameterException thrown if the rectangle's values are invalid
	 */
	public static Rectangle parse(String retangleInfo) throws InvalidRectangleParameterException {
		List<String> infoList = new ArrayList<String>(Arrays.asList(retangleInfo.split(",")));
		// checks if their are too many or not enough variables for a rectangle
		if (infoList.size() != NUMBEROFPARAMETERS) {
			throw new InvalidRectangleParameterException(
					"The rectangle has invalid  number of parameters:" + infoList.size());
		}
		try {
			// converts the text file parameters into doubles
			double height = Double.parseDouble(infoList.get(1));
			double width = Double.parseDouble(infoList.get(2));
			Rectangle newRectangle = new Rectangle(height, width);
			return newRectangle;
			
		} 
		// thrown if the parameters for the height and width cannot be converted to doubles
		catch (java.lang.NumberFormatException e) {
			throw new InvalidRectangleParameterException(
					"The retangle has invalid parameters: height: "+infoList.get(1)+" or width: " +infoList.get(2) +"is not a number");
		}
	}
	public void setWidth(double width) {
		this.width = width;
	}

	public void setHeight(double height) {
		this.height = height;
	}
	public double getWidth() {
		return this.width;
	}

	public double getHeight() {
		return this.height;
	}
	/**
	 * returns the preimeter of the rectangle
	 * @return double preimeter of the rectangle
	 */
	public double getPerimeter() {
		double totalHeight = this.height * 2;
		double totalWidth = this.width * 2;
		return totalHeight + totalWidth;
	}
	/**
	 * returns the area of the rectangle
	 * @return double area of the rectangle
	 */
	public double getArea() {
		return this.height * this.width;
	}
}