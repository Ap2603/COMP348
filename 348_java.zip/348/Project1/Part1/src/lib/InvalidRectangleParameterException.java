package lib;

/**
 * @author Alessandro Dare
 * @version 1.0
 * Throws an exception when a rectangle shape is given incorrect info in the text file
 */
public class InvalidRectangleParameterException extends Exception  
{  
	/**
	 * Main constructor of the class
	 * @param message String error message
	 */
    public InvalidRectangleParameterException (String message)  
    {  
         
        super(message);  
    }  
}
