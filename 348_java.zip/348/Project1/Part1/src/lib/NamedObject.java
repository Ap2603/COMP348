
package lib;

/**
 * @author Alessandro Dare
 * @version 1.0
 * An interface to make sure all classes with this interface have a name
 */
public interface NamedObject {
	/**
	 * returns the class name by deafault
	 * @return String object name
	 */
	default public String getName() {
		return this.getClass().getName();
	}
}
