package lib;

/**
 * @author Alessandro Dare
 * @version 1.0
 * Throws an exception when a line in the file is not shape info
 */
public class NotAShapeException extends Exception  
{  
	/**
	 * Main constructor of the class
	 * @param message String error message
	 */
    public NotAShapeException (String message)  
    {  
         
        super(message);  
    }  
}
