package lib;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * @author Alessandro Dare
 * @version 1.0
 * Reads from a file and takes it's information to create a list of shapes, 
 * then prints the list of shapes ordered by name and area
 */
public class ShapeFinder {
	private static final String RECTANGLE = "rectangle";
	private static final String CIRCLE = "circle";
	/**
	 * Main method takes info from file and prints the list
	 * @param args String
	 */
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		String path = sc.nextLine();
		String line = "";
		//scans the file
		try (BufferedReader br = new BufferedReader(new FileReader(path))) {
			List<Shape> shapeInfo = new ArrayList<Shape>();
			while ((line = br.readLine()) != null) {
				//removes any lines that are blank
				if(line!=null&&(!line.replaceAll("\\s", "").equals(""))) {
					shapeInfo.add(getShape(line));
				}
			}
			Collections.sort(shapeInfo, new SortByShape(new SortByName(),new SortByArea()));
			//turns list into an array so it can be printed
			Shape[]shapeArray = new Shape[shapeInfo.size()];
			for (int i = 0; i < shapeInfo.size(); i++) {
				shapeArray[i] = shapeInfo.get(i);
			}
			Printable.print(java.util.Arrays.copyOf(shapeArray, shapeArray.length, Printable[].class));
		} 
		//if a exception occurs the exception message i printed and the program halted
		catch (FileNotFoundException e) {
			System.out.println("Error:file path not specificed");
			System.out.println(e.getMessage());
			//e.printStackTrace();
		}  
		catch (NotAShapeException e) {
			System.out.println("Error:line given is not a shape or circle");
			System.out.println(e.getMessage());
			//e.printStackTrace();
		} 
		catch (InvalidRectangleParameterException e) {
			System.out.println("Error:rectangle has invalid parameters");
			System.out.println(e.getMessage());
			//e.printStackTrace();
		} 
		catch (InvalidCircleParameterException e) {
			System.out.println("Error:circle has invalid parameters");
			System.out.println(e.getMessage());
			//e.printStackTrace();
		}
		catch (IOException e) {
			System.out.println(e.getMessage());
			//e.printStackTrace();
		} finally {

			sc.close();
		}
	}
	/**
	 * takes the information form the file and converts it into a shape
	 * @param fileShape String the information from the shape 
	 * @return Shape the completed shape
	 * @throws NotAShapeException thrown if the information given is not a shape
	 * @throws InvalidRectangleParameterException thrown if the information given for perimeter or height is invalid
	 * @throws InvalidCircleParameterException thrown if the information given for the radius is invalid
	 */
	private static Shape getShape(String fileShape) throws NotAShapeException, InvalidRectangleParameterException, InvalidCircleParameterException {
		fileShape=fileShape.replaceAll("\\s", "");
		List<String> infoList = new ArrayList<String>(Arrays.asList(fileShape.split(",")));
		//finds if is a rectangle or a circle then converts accordingly
		if (RECTANGLE.equals(infoList.get(0).toLowerCase())) {
			return Rectangle.parse(fileShape);
		} else if (CIRCLE.equals(infoList.get(0).toLowerCase())) {
			return Circle.parse(fileShape);
		} else {
			//not a shape throws an exception
			throw new NotAShapeException("line given is not a shape or circle");    
		}
	}
}
